package com.ProductAssesment.product.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.ProductAssesment.product.entity.Entity;


@Component
public class ProductService {
	private static List<Entity> list = new ArrayList<>();
	
	static {
		list.add(new Entity(12, "realme" , 2123,2, 25893));
		list.add(new Entity(5, "iphone" , 255, 5,36544));
		list.add(new Entity(12, "moto" , 25, 6,25356));
		list.add(new Entity(19, "lava" , 263, 1,25751));
		list.add(new Entity(12, "nokia" , 93, 9,12563));
	}
	//get all Entity
	public List<Entity> getallEntity()
	{
		return list;
	}
	
	// get  by id
	public Entity getEntityById(int id)
	{
		Entity entity = null;
		
		entity = list.stream().filter(e->e.getId_category() == 5 && e.price>200 && e.price<1500 ).findFirst().get();
		return entity;
	}
}
