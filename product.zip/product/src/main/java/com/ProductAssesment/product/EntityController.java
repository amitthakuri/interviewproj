package com.ProductAssesment.product;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.ProductAssesment.product.entity.Entity;
import com.ProductAssesment.product.service.ProductService;

 

@RestController
public class EntityController {
	
	@Autowired
	private ProductService productServ;
	
	@GetMapping("/Entity")
	public List<Entity> getEntity()
	{		
		return this.productServ.getallEntity();
	} 
	
	@GetMapping("/Entity/{id_product}")
	public Entity getentity(@PathVariable("id_product")int id)
	{
	return productServ.getEntityById(id);
	}
}
