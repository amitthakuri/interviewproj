package com.ProductAssesment.product.entity;

public class Entity {
	private int id_product;
	private String name;
	public int price;
	private int id_vendor;
	private int id_category;
	public Entity(int id_product, String name, int price, int id_vendor, int id_category) {
		super();
		this.id_product = id_product;
		this.name = name;
		this.price = price;
		this.id_vendor = id_vendor;
		this.id_category = id_category;
	}
	public Entity() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getId_product() {
		return id_product;
	}
	public void setId_product(int id_product) {
		this.id_product = id_product;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getId_vendor() {
		return id_vendor;
	}
	public void setId_vendor(int id_vendor) {
		this.id_vendor = id_vendor;
	}
	public int getId_category() {
		return id_category;
	}
	public void setId_category(int id_category) {
		this.id_category = id_category;
	}
	
	
}
